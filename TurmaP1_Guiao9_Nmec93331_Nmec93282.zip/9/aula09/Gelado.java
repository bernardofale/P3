package aula09;

public interface Gelado{
    public void base(int x); //nmr de bolas de gelado
}