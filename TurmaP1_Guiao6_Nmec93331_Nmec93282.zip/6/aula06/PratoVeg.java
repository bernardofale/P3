package aula06;

interface PratoVeg {
}
