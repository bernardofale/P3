import aula08.jogodogalo;
public class ex81{

    public static void main(String args[]) {
        new jogodogalo(args[0]);
     
 
 
 }
}