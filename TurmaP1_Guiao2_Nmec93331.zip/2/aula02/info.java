package aula02;
public class info{
	private final int nmec;
	private String curso;
	
	public info(int nmec, String curso) {
		this.nmec=nmec;
		this.curso=curso;
	}
}