package aula02;

public class func{
	private int nfunc;
	private int nfiscal;
	
	public func(int nfunc, int nfiscal) {
		this.nfunc=nfunc;
		this.nfiscal=nfiscal;
	}
}