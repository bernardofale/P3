package aula02;

public class estudantes {
	private Pessoa p;
	private info c;
	
	public estudantes(Pessoa p, info c) {
		this.p=p;
		this.c=c;
	}
	
	public Pessoa p() {
		return this.p;
	}
}
