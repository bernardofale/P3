import java.util.*;
import java.io.*;
import aula02.letterSoup;

public class ex22{

public static void main(String[] args) throws Exception {
	letterSoup sopa=new letterSoup(args[0]);
	//sopa.play(sopa.s);
	}
}